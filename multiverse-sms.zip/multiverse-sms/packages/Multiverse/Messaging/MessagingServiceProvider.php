<?php

namespace Multiverse\Messaging;

use Illuminate\Support\ServiceProvider;
use Multiverse\Messaging\Facades\Sms;

class MessagingServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(SmsManager::class, function ($app) {
            return new SmsManager(config('sms'));
        });

        $this->app->alias(SmsManager::class, 'sms');
    }

    public function boot(): void
    {
        $this->publishes([
            __DIR__ . '/../../config/sms.php' => config_path('sms.php'),
        ], 'multiverse-sms-config');
    }
}
