<?php

namespace Multiverse\Messaging;

use Multiverse\Messaging\Contracts\SmsDriverInterface;
use Multiverse\Messaging\Drivers\JasminDriver;
use Multiverse\Messaging\Drivers\SmppDriver;
use Multiverse\Messaging\Drivers\LogDriver;
use InvalidArgumentException;

/**
 * Multiverse SMS Manager
 *
 * Usage:
 *   Sms::send(['to' => '2557XXXXXXX', 'message' => 'Hello!', 'sender' => 'MULTIVERSE']);
 *   Sms::via('smpp')->send([...]);
 */
class SmsManager
{
    protected array $config;
    protected array $drivers = [];

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function driver(?string $name = null): SmsDriverInterface
    {
        $name = $name ?? $this->config['default'];

        if (!isset($this->drivers[$name])) {
            $this->drivers[$name] = $this->createDriver($name);
        }

        return $this->drivers[$name];
    }

    public function via(string $driver): SmsDriverInterface
    {
        return $this->driver($driver);
    }

    protected function createDriver(string $name): SmsDriverInterface
    {
        $config = $this->config['drivers'][$name] ?? null;

        if ($config === null) {
            throw new InvalidArgumentException("SMS driver [{$name}] is not configured.");
        }

        return match ($name) {
            'jasmin' => new JasminDriver($config),
            'smpp'   => new SmppDriver($config),
            'log'    => new LogDriver(),
            default  => throw new InvalidArgumentException("Unsupported SMS driver [{$name}]."),
        };
    }

    /**
     * Quick send shorthand.
     *
     * @param array $params ['to', 'message', 'sender' (optional)]
     */
    public function send(array $params): array
    {
        return $this->driver()->send(
            $params['to'],
            $params['message'],
            $params['sender'] ?? $this->config['default_sender']
        );
    }

    public function sendBulk(array $recipients): array
    {
        return $this->driver()->sendBulk($recipients);
    }
}
