<?php

namespace Multiverse\Messaging\Contracts;

interface SmsDriverInterface
{
    public function send(string $to, string $message, string $sender): array;
    public function sendBulk(array $recipients): array;
    public function getDeliveryStatus(string $messageId): string;
    public function getName(): string;
}
