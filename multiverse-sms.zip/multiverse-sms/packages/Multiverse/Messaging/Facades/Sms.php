<?php

namespace Multiverse\Messaging\Facades;

use Illuminate\Support\Facades\Facade;
use Multiverse\Messaging\SmsManager;

/**
 * @method static array send(array $params)
 * @method static array sendBulk(array $recipients)
 * @method static \Multiverse\Messaging\Contracts\SmsDriverInterface driver(?string $name = null)
 * @method static \Multiverse\Messaging\Contracts\SmsDriverInterface via(string $driver)
 *
 * @see \Multiverse\Messaging\SmsManager
 */
class Sms extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return SmsManager::class;
    }
}
