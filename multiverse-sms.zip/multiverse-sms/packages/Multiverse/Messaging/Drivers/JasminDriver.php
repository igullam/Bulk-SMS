<?php

namespace Multiverse\Messaging\Drivers;

use Multiverse\Messaging\Contracts\SmsDriverInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class JasminDriver implements SmsDriverInterface
{
    protected array $config;
    protected string $baseUrl;

    public function __construct(array $config)
    {
        $this->config  = $config;
        $this->baseUrl = "http://{$config['host']}:{$config['port']}";
    }

    public function getName(): string
    {
        return 'jasmin';
    }

    public function send(string $to, string $message, string $sender): array
    {
        try {
            $response = Http::withBasicAuth($this->config['username'], $this->config['password'])
                ->post("{$this->baseUrl}/send", [
                    'to'        => $to,
                    'from'      => $sender,
                    'content'   => $message,
                    'dlr'       => 'yes',
                    'dlr-url'   => config('sms.dlr_webhook_url'),
                    'dlr-level' => 1,
                ]);

            if ($response->successful()) {
                $body      = trim($response->body());
                $messageId = str_replace(['Success "', '"'], '', $body);
                return ['success' => true, 'message_id' => $messageId, 'status' => 'sent'];
            }

            return ['success' => false, 'error' => $response->body(), 'status' => 'failed'];
        } catch (Exception $e) {
            Log::error('Jasmin Send Error: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage(), 'status' => 'failed'];
        }
    }

    public function sendBulk(array $recipients): array
    {
        return array_map(
            fn($r) => $this->send($r['to'], $r['message'], $r['sender'] ?? config('sms.default_sender')),
            $recipients
        );
    }

    public function getDeliveryStatus(string $messageId): string
    {
        return 'ENROUTE';
    }
}
