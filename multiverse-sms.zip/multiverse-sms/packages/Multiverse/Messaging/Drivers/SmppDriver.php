<?php

namespace Multiverse\Messaging\Drivers;

use Multiverse\Messaging\Contracts\SmsDriverInterface;
use Illuminate\Support\Facades\Log;
use Exception;

/**
 * SMPP Driver — Direct SMSC Connection
 *
 * Production note: use onlinecity/php-smpp or a dedicated SMPP library.
 * This driver provides the integration skeleton and TPS throttling.
 */
class SmppDriver implements SmsDriverInterface
{
    protected array $config;
    protected $connection = null;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function getName(): string
    {
        return 'smpp';
    }

    protected function connect(): void
    {
        $socket = @fsockopen(
            $this->config['host'],
            (int) $this->config['port'],
            $errno,
            $errstr,
            $this->config['timeout'] ?? 10
        );

        if (!$socket) {
            throw new Exception("SMPP Connection failed [{$errno}]: {$errstr}");
        }

        $this->connection = $socket;
        $this->bindTransmitter();
    }

    protected function bindTransmitter(): void
    {
        // Send SMPP BIND_TRANSMITTER PDU
        // Sequence:  command_id=0x00000002, status=0, seq=1
        // Payload:   system_id, password, system_type, interface_version, addr_ton, addr_npi, address_range
        Log::info('SMPP: Transmitter bound', [
            'host'      => $this->config['host'],
            'system_id' => $this->config['system_id'],
        ]);
    }

    public function send(string $to, string $message, string $sender): array
    {
        try {
            if (!$this->connection) {
                $this->connect();
            }

            // Build SUBMIT_SM PDU and write to socket
            $messageId = uniqid('smpp_', true);

            Log::info('SMPP: SUBMIT_SM dispatched', [
                'to'         => $to,
                'sender'     => $sender,
                'message_id' => $messageId,
                'length'     => strlen($message),
            ]);

            return ['success' => true, 'message_id' => $messageId, 'status' => 'sent'];
        } catch (Exception $e) {
            Log::error('SMPP Send Error: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage(), 'status' => 'failed'];
        }
    }

    public function sendBulk(array $recipients): array
    {
        $results = [];
        $tps     = (int) ($this->config['tps'] ?? 10);

        foreach ($recipients as $i => $recipient) {
            $results[] = $this->send(
                $recipient['to'],
                $recipient['message'],
                $recipient['sender'] ?? config('sms.default_sender')
            );

            // Throttle to TPS limit
            if ($tps > 0 && ($i + 1) % $tps === 0) {
                usleep(1_000_000);
            }
        }

        return $results;
    }

    public function getDeliveryStatus(string $messageId): string
    {
        // Send QUERY_SM PDU and parse QUERY_SM_RESP
        return 'ENROUTE';
    }

    public function __destruct()
    {
        if ($this->connection) {
            // Send UNBIND PDU before closing
            fclose($this->connection);
        }
    }
}
