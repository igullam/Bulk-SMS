# 🌌 Multiverse SMS Platform

> **Enterprise Bulk SMS & WhatsApp Messaging Platform**
> Built with Laravel 11 · SMPP · Jasmin Gateway · Meta Cloud API · Wedding Module

---

## 📋 Overview

Multiverse SMS is a production-ready SaaS messaging platform for Tanzania and East Africa that enables:

- **Bulk SMS** via direct SMPP connection (Yas Tanzania, Airtel, Tigo, etc.)
- **WhatsApp Business** messaging via Meta Cloud API
- **Wedding & Event Management** with guest lists, RSVP, QR check-in
- **Wallet billing** system with TZS support
- **Campaign management** with scheduling, delivery reports, and analytics

---

## 🏗️ Architecture

```
                    USERS (Web / API)
                           │
                    Laravel 11 App
            (Campaigns / Users / Billing / API)
                           │
                      Redis Queue
                           │
            ┌──────────────┴──────────────┐
            ▼                             ▼
     SMS Engine (SMPP)            WhatsApp Engine
            │                             │
       Jasmin Gateway              Meta Cloud API
            │
       VPN / IPSec Tunnel
            │
     Telecom SMSC (Yas / Airtel)
            │
         Recipients
```

---

## 🚀 Quick Start

### 1. Clone & Configure

```bash
git clone https://github.com/your-org/multiverse-sms.git
cd multiverse-sms
cp .env.example .env
```

Edit `.env` with your credentials:

```dotenv
# Database
DB_DATABASE=multiverse_sms
DB_USERNAME=root
DB_PASSWORD=your_password

# SMPP (request from Yas Tanzania)
SMPP_HOST=smsc.yas.co.tz
SMPP_PORT=2775
SMPP_SYSTEM_ID=your_id
SMPP_PASSWORD=your_password

# WhatsApp
WHATSAPP_PHONE_NUMBER_ID=your_phone_id
WHATSAPP_ACCESS_TOKEN=your_token
```

### 2. Install & Migrate

```bash
composer install
php artisan key:generate
php artisan migrate --seed
php artisan storage:link
```

### 3. Start with Docker

```bash
docker-compose up -d
```

Or manually:

```bash
# Terminal 1 — Web server
php artisan serve

# Terminal 2 — SMS Queue
php artisan queue:work redis --queue=sms

# Terminal 3 — WhatsApp Queue
php artisan queue:work redis --queue=whatsapp

# Terminal 4 — Scheduler
php artisan schedule:work
```

### Default Credentials

| Role  | Email                       | Password   |
|-------|-----------------------------|------------|
| Admin | admin@multiversesms.com     | password   |
| Demo  | demo@multiversesms.com      | demo1234   |

---

## 📡 API Reference

### Authentication

```bash
# Register
POST /api/auth/register
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password",
  "password_confirmation": "password"
}

# Login
POST /api/auth/login
{
  "email": "john@example.com",
  "password": "password"
}
# Returns: { "token": "..." }
```

Use the token as: `Authorization: Bearer {token}`

### Send Bulk SMS Campaign

```bash
POST /api/campaigns
Authorization: Bearer {token}

{
  "name": "Promo Campaign July",
  "type": "sms",
  "message": "Dear customer, get 20% off today! Call 0700000000",
  "sender_id": "MULTIVERSE",
  "contacts": [
    "255700000001",
    "255700000002"
  ]
}

# Launch it
POST /api/campaigns/{id}/launch
```

### Wallet Top-Up

```bash
POST /api/wallet/topup
{
  "amount": 50000,
  "payment_method": "mpesa",
  "reference": "MPESA_REF_123"
}
```

### Wedding Event

```bash
# Create event
POST /api/wedding
{
  "name": "Amina & Juma Wedding",
  "type": "wedding",
  "venue": "Serena Hotel, Dar es Salaam",
  "event_date": "2024-12-14",
  "bride_name": "Amina",
  "groom_name": "Juma",
  "wedding_package_id": 3
}

# Import guests (Excel)
POST /api/wedding/{event_id}/import-guests
Content-Type: multipart/form-data
file: guests.xlsx

# Send invitations
POST /api/wedding/{event_id}/send-invitations
{
  "send_whatsapp": true
}

# Check-in via QR
POST /api/checkin/{token}
```

---

## 📦 SMS Package Usage

The `Sms` facade can be used anywhere in the application:

```php
use Multiverse\Messaging\Facades\Sms;

// Simple send
Sms::send([
    'to'      => '255700000001',
    'message' => 'Hello from Multiverse SMS!',
    'sender'  => 'MULTIVERSE',
]);

// Switch driver
Sms::via('smpp')->send([...]);

// Bulk send
Sms::sendBulk([
    ['to' => '255700000001', 'message' => 'Msg 1', 'sender' => 'INFO'],
    ['to' => '255700000002', 'message' => 'Msg 2', 'sender' => 'INFO'],
]);
```

---

## 💍 Wedding Module

### Packages

| Package | SMS     | WhatsApp | QR Check-in | Analytics | Price (TZS) |
|---------|---------|----------|-------------|-----------|-------------|
| Basic   | 500     | ❌        | ❌           | ❌         | 50,000      |
| Premium | 1,000   | ✅        | ❌           | ❌         | 120,000     |
| VIP     | ∞       | ✅        | ✅           | ✅         | 350,000     |

### Excel Import Format

Prepare your guest list with these columns:

```
name | phone        | email              | family | seat | table
-----|--------------|--------------------|----|------|------
Amina| 255700000001 | amina@example.com  | Doe|  A1  |  1
Juma | 255700000002 |                    |    |  A2  |  1
```

---

## 🔐 SMPP + VPN Setup

### Yas Tanzania SMPP Requirements

Request the following from Yas enterprise team:

1. SMPP Host & Port (usually `2775`)
2. System ID & Password
3. Sender ID approval
4. TPS (Transactions Per Second) limit
5. VPN/IPSec credentials + peer IP

### VPN Tunnel (IPSec/StrongSwan)

```bash
# Install StrongSwan
sudo apt install strongswan

# /etc/ipsec.conf
conn yas-tunnel
    keyexchange=ikev2
    left=%defaultroute
    leftid=YOUR_SERVER_IP
    right=YAS_PEER_IP
    rightid=YAS_PEER_IP
    leftsubnet=10.0.0.0/24
    rightsubnet=10.1.0.0/24
    ike=aes256-sha256-modp2048!
    esp=aes256-sha256!
    auto=start
```

---

## 🐳 Production Deployment

```bash
# Build and start
docker-compose -f docker-compose.yml up -d --build

# Run migrations
docker exec multiverse_app php artisan migrate --seed --force

# Monitor queues
docker exec multiverse_app php artisan horizon

# View logs
docker logs -f multiverse_worker
```

---

## 📂 Project Structure

```
multiverse-sms/
├── app/
│   ├── Http/Controllers/
│   │   ├── Api/          (CampaignController, WeddingController, DlrController)
│   │   ├── Auth/         (AuthController)
│   │   └── Billing/      (WalletController)
│   ├── Models/           (User, Campaign, Message, Event, Guest, Rsvp, Wallet...)
│   ├── Services/
│   │   ├── Sms/          (SmsService, WalletService)
│   │   ├── WhatsApp/     (WhatsAppService)
│   │   └── Wedding/      (WeddingService)
│   └── Jobs/             (SendSmsJob, SendWhatsAppJob)
├── packages/
│   └── Multiverse/
│       └── Messaging/    (SmsManager, Drivers, Contracts, Facades)
├── database/migrations/
├── config/               (sms.php, whatsapp.php, wedding.php)
├── docker/               (Dockerfile, nginx, supervisord)
├── docker-compose.yml
└── routes/api.php
```

---

## 📞 Support

- Platform: **Multiverse SMS** — *Tanzania & East Africa*
- Currency: **TZS**
- Timezone: **Africa/Dar_es_Salaam**

---

*Built with ❤️ for the East African market*
