<?php

// ═══════════════════════════════════════════════════════════════════════════════
// MULTIVERSE SMS — Database Migrations
// Run: php artisan migrate
// ═══════════════════════════════════════════════════════════════════════════════

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// ── 2024_01_01_000001_create_users_table.php ─────────────────────────────────
return new class extends Migration {
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('phone')->nullable();
            $table->string('company')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('timezone')->default('Africa/Dar_es_Salaam');
            $table->boolean('is_active')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });

        // ── Wallets ───────────────────────────────────────────────────────────
        Schema::create('wallets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->decimal('balance', 12, 2)->default(0);
            $table->string('currency', 3)->default('TZS');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Transactions ──────────────────────────────────────────────────────
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('wallet_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('type', ['credit', 'debit']);
            $table->decimal('amount', 12, 2);
            $table->decimal('balance', 12, 2)->comment('Balance after transaction');
            $table->string('currency', 3)->default('TZS');
            $table->string('reference')->nullable();
            $table->string('description')->nullable();
            $table->enum('status', ['pending', 'completed', 'failed', 'reversed'])->default('completed');
            $table->string('payment_method')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
        });

        // ── Contact Groups ────────────────────────────────────────────────────
        Schema::create('contact_groups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('description')->nullable();
            $table->integer('contacts_count')->default(0);
            $table->timestamps();
        });

        // ── Contacts ──────────────────────────────────────────────────────────
        Schema::create('contacts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('group_id')->nullable()->constrained('contact_groups')->nullOnDelete();
            $table->string('name')->nullable();
            $table->string('phone');
            $table->string('email')->nullable();
            $table->json('tags')->nullable();
            $table->json('meta')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamp('opted_out_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['user_id', 'phone']);
        });

        // ── Sender IDs ────────────────────────────────────────────────────────
        Schema::create('sender_ids', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('sender', 11);
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->text('rejection_reason')->nullable();
            $table->timestamps();
            $table->unique(['user_id', 'sender']);
        });

        // ── Campaigns ─────────────────────────────────────────────────────────
        Schema::create('campaigns', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->enum('type', ['sms', 'whatsapp', 'both'])->default('sms');
            $table->text('message');
            $table->string('sender_id')->nullable();
            $table->enum('status', ['draft', 'scheduled', 'running', 'completed', 'failed', 'paused'])->default('draft');
            $table->timestamp('scheduled_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->unsignedInteger('total_recipients')->default(0);
            $table->unsignedInteger('sent_count')->default(0);
            $table->unsignedInteger('delivered_count')->default(0);
            $table->unsignedInteger('failed_count')->default(0);
            $table->decimal('cost', 10, 2)->default(0);
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // ── Messages ──────────────────────────────────────────────────────────
        Schema::create('messages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('campaign_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('contact_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('type', ['sms', 'whatsapp'])->default('sms');
            $table->string('to');
            $table->text('message');
            $table->string('sender')->nullable();
            $table->string('gateway_message_id')->nullable()->index();
            $table->enum('status', ['pending', 'sent', 'delivered', 'failed', 'expired'])->default('pending')->index();
            $table->decimal('cost', 8, 4)->default(0);
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamp('failed_at')->nullable();
            $table->string('error_code')->nullable();
            $table->text('error_message')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'status']);
            $table->index(['campaign_id', 'status']);
        });

        // ── Message Logs ──────────────────────────────────────────────────────
        Schema::create('message_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('message_id')->constrained()->cascadeOnDelete();
            $table->string('event');
            $table->string('status');
            $table->json('gateway_response')->nullable();
            $table->text('error')->nullable();
            $table->timestamp('logged_at')->useCurrent();
            $table->timestamps();
        });

        // ── Wedding Packages ──────────────────────────────────────────────────
        Schema::create('wedding_packages', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->integer('sms_units')->default(500)->comment('-1 = unlimited');
            $table->boolean('whatsapp_enabled')->default(false);
            $table->boolean('qr_checkin')->default(false);
            $table->boolean('analytics')->default(false);
            $table->decimal('price', 10, 2)->default(0);
            $table->string('currency', 3)->default('TZS');
            $table->boolean('is_active')->default(true);
            $table->json('features')->nullable();
            $table->timestamps();
        });

        // ── Events ────────────────────────────────────────────────────────────
        Schema::create('events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('wedding_package_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->enum('type', ['wedding', 'birthday', 'corporate', 'other'])->default('wedding');
            $table->text('description')->nullable();
            $table->string('venue');
            $table->date('event_date');
            $table->time('event_time')->nullable();
            $table->string('bride_name')->nullable();
            $table->string('groom_name')->nullable();
            $table->string('cover_image')->nullable();
            $table->json('settings')->nullable();
            $table->enum('status', ['draft', 'active', 'completed', 'cancelled'])->default('draft');
            $table->unsignedInteger('total_guests')->default(0);
            $table->unsignedInteger('confirmed_rsvps')->default(0);
            $table->unsignedInteger('declined_rsvps')->default(0);
            $table->unsignedInteger('pending_rsvps')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });

        // ── Guests ────────────────────────────────────────────────────────────
        Schema::create('guests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('phone');
            $table->string('email')->nullable();
            $table->string('family_name')->nullable();
            $table->string('seat_number')->nullable();
            $table->string('table_number')->nullable();
            $table->timestamp('invitation_sent_at')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->unique(['event_id', 'phone']);
        });

        // ── RSVPs ─────────────────────────────────────────────────────────────
        Schema::create('rsvps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained()->cascadeOnDelete();
            $table->foreignId('guest_id')->constrained()->cascadeOnDelete();
            $table->string('token', 64)->unique();
            $table->enum('response', ['pending', 'confirmed', 'declined', 'maybe'])->default('pending');
            $table->unsignedTinyInteger('attending_count')->default(1);
            $table->string('dietary_notes')->nullable();
            $table->text('message')->nullable();
            $table->timestamp('responded_at')->nullable();
            $table->timestamp('checked_in_at')->nullable();
            $table->string('qr_code')->nullable();
            $table->timestamps();
            $table->unique(['event_id', 'guest_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rsvps');
        Schema::dropIfExists('guests');
        Schema::dropIfExists('events');
        Schema::dropIfExists('wedding_packages');
        Schema::dropIfExists('message_logs');
        Schema::dropIfExists('messages');
        Schema::dropIfExists('campaigns');
        Schema::dropIfExists('sender_ids');
        Schema::dropIfExists('contacts');
        Schema::dropIfExists('contact_groups');
        Schema::dropIfExists('transactions');
        Schema::dropIfExists('wallets');
        Schema::dropIfExists('users');
    }
};
