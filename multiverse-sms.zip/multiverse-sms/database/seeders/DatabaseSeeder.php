<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\WeddingPackage;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ── Admin User ────────────────────────────────────────────────────────
        $admin = User::firstOrCreate(
            ['email' => 'admin@multiversesms.com'],
            [
                'name'     => 'Multiverse Admin',
                'password' => Hash::make('password'),
                'phone'    => '+255700000000',
                'company'  => 'Multiverse SMS',
                'is_active'=> true,
            ]
        );

        $admin->wallet()->firstOrCreate([], ['balance' => 500000, 'currency' => 'TZS']);

        // ── Demo User ─────────────────────────────────────────────────────────
        $demo = User::firstOrCreate(
            ['email' => 'demo@multiversesms.com'],
            [
                'name'     => 'Demo User',
                'password' => Hash::make('demo1234'),
                'phone'    => '+255700000001',
                'is_active'=> true,
            ]
        );

        $demo->wallet()->firstOrCreate([], ['balance' => 50000, 'currency' => 'TZS']);

        // ── Wedding Packages ──────────────────────────────────────────────────
        $packages = [
            [
                'name'             => 'Basic',
                'slug'             => 'basic',
                'description'      => 'Perfect for small, intimate weddings.',
                'sms_units'        => 500,
                'whatsapp_enabled' => false,
                'qr_checkin'       => false,
                'analytics'        => false,
                'price'            => 50000,
                'currency'         => 'TZS',
                'features'         => ['SMS invitations', 'Guest list management', 'RSVP tracking'],
            ],
            [
                'name'             => 'Premium',
                'slug'             => 'premium',
                'description'      => 'The most popular package for medium weddings.',
                'sms_units'        => 1000,
                'whatsapp_enabled' => true,
                'qr_checkin'       => false,
                'analytics'        => false,
                'price'            => 120000,
                'currency'         => 'TZS',
                'features'         => ['1000 SMS invitations', 'WhatsApp invitations', 'Automated reminders', 'RSVP management', 'Family grouping'],
            ],
            [
                'name'             => 'VIP',
                'slug'             => 'vip',
                'description'      => 'The ultimate experience for grand weddings.',
                'sms_units'        => -1,
                'whatsapp_enabled' => true,
                'qr_checkin'       => true,
                'analytics'        => true,
                'price'            => 350000,
                'currency'         => 'TZS',
                'features'         => ['Unlimited SMS', 'WhatsApp invitations', 'QR Code check-in', 'Real-time analytics', 'Priority support', 'Custom branding'],
            ],
        ];

        foreach ($packages as $pkg) {
            WeddingPackage::firstOrCreate(['slug' => $pkg['slug']], $pkg);
        }

        $this->command->info('✅ Multiverse SMS seeded successfully.');
        $this->command->info('   Admin: admin@multiversesms.com / password');
        $this->command->info('   Demo:  demo@multiversesms.com / demo1234');
    }
}
