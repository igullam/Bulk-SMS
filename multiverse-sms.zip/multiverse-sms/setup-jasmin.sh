#!/bin/bash

# ═══════════════════════════════════════════════════════════════════════════════
#  Multiverse SMS — Jasmin + VPN Setup Script
#  Ubuntu 22.04 / 24.04
#  Run as root: bash setup-jasmin.sh
# ═══════════════════════════════════════════════════════════════════════════════

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
info() { echo -e "${CYAN}[i]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     MULTIVERSE SMS — Jasmin + VPN Setup      ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════╝${NC}"
echo ""

# ── 1. System Update ──────────────────────────────────────────────────────────
info "Updating system packages..."
apt-get update -qq && apt-get upgrade -y -qq
log "System updated"

# ── 2. Install Dependencies ───────────────────────────────────────────────────
info "Installing dependencies..."
apt-get install -y -qq \
    python3 python3-pip python3-venv \
    git curl wget supervisor \
    rabbitmq-server \
    redis-server \
    strongswan strongswan-pki libcharon-extra-plugins \
    build-essential libssl-dev libffi-dev python3-dev
log "Dependencies installed"

# ── 3. Install Jasmin SMS Gateway ─────────────────────────────────────────────
info "Installing Jasmin SMS Gateway..."
pip3 install jasmin --quiet
log "Jasmin installed"

# ── 4. Configure Jasmin ───────────────────────────────────────────────────────
info "Configuring Jasmin..."

mkdir -p /etc/jasmin/store
mkdir -p /var/log/jasmin

cat > /etc/jasmin/jasmin.cfg << 'EOF'
[globals]
store_path = /etc/jasmin/store

[logger]
log_level = INFO
log_file = /var/log/jasmin/jasmin.log

[smpp-server]
port = 2775

[rest-api]
port = 8080
cors_policy_origin = *

[amqp-broker]
host = localhost
port = 5672
username = guest
password = guest
vhost = /
EOF

log "Jasmin configured"

# ── 5. Jasmin Systemd Service ─────────────────────────────────────────────────
cat > /etc/systemd/system/jasmin.service << 'EOF'
[Unit]
Description=Jasmin SMS Gateway
After=network.target rabbitmq-server.service

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/jasmind.py --username=admin --password=admin start
ExecStop=/usr/local/bin/jasmind.py stop
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable jasmin
systemctl start rabbitmq-server
sleep 3
systemctl start jasmin

log "Jasmin service started"

# ── 6. Configure SMPP Connection via Jasmin CLI ───────────────────────────────
info "You must now configure your SMPP connector via Jasmin CLI:"
echo ""
echo -e "${YELLOW}  telnet localhost 8989${NC}"
echo -e "${YELLOW}  Username: admin${NC}"
echo -e "${YELLOW}  Password: admin${NC}"
echo ""
echo "  Then run these commands:"
echo ""
echo "  > smppccm -a                    # Add connector"
echo "  > cid yas_connector"
echo "  > host smsc.yas.co.tz"
echo "  > port 2775"
echo "  > username YOUR_SYSTEM_ID"
echo "  > password YOUR_PASSWORD"
echo "  > systemType ''"
echo "  > bindOperation transceiver"
echo "  > ok"
echo "  > smppccm -1 yas_connector      # Start connector"
echo ""

# ── 7. IPSec VPN Setup ────────────────────────────────────────────────────────
warn "Configuring IPSec VPN skeleton (fill in your Yas credentials)..."

cat > /etc/ipsec.conf << 'EOF'
config setup
    charondebug="ike 1, knl 1, cfg 0"
    uniqueids=never

conn %default
    ikelifetime=60m
    keylife=20m
    rekeymargin=3m
    keyingtries=1
    keyexchange=ikev2
    authby=secret

conn yas-smsc-tunnel
    left=%defaultroute
    leftid=YOUR_SERVER_PUBLIC_IP
    right=YAS_VPN_PEER_IP
    rightid=YAS_VPN_PEER_IP
    leftsubnet=YOUR_LOCAL_SUBNET/24
    rightsubnet=YAS_SMSC_SUBNET/24
    ike=aes256-sha256-modp2048!
    esp=aes256-sha256!
    auto=start
    type=tunnel
EOF

cat > /etc/ipsec.secrets << 'EOF'
YOUR_SERVER_PUBLIC_IP YAS_VPN_PEER_IP : PSK "YOUR_PRE_SHARED_KEY"
EOF

chmod 600 /etc/ipsec.secrets

log "IPSec config skeleton created at /etc/ipsec.conf"
warn "Edit /etc/ipsec.conf and /etc/ipsec.secrets with your Yas credentials, then run: ipsec start"

# ── 8. Supervisor Config for Workers ─────────────────────────────────────────
cp /path/to/multiverse-sms/docker/supervisord.conf /etc/supervisor/conf.d/multiverse.conf 2>/dev/null || true

# ── 9. Summary ────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         SETUP COMPLETE!                      ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Jasmin REST API:  ${CYAN}http://localhost:8080${NC}"
echo -e "  Jasmin CLI:       ${CYAN}telnet localhost 8989${NC}"
echo -e "  Jasmin SMPP:      ${CYAN}localhost:2775${NC}"
echo -e "  RabbitMQ:         ${CYAN}localhost:5672${NC}"
echo ""
warn "NEXT STEPS:"
echo "  1. Edit /etc/ipsec.conf with your Yas VPN credentials"
echo "  2. Run: ipsec start && ipsec statusall"
echo "  3. Configure SMPP connector via Jasmin CLI"
echo "  4. Test with: php artisan tinker"
echo "     > Sms::send(['to'=>'2557...', 'message'=>'Test', 'sender'=>'TEST'])"
echo ""
