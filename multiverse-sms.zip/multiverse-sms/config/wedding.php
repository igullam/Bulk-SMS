<?php

return [
    'rsvp_base_url' => env('WEDDING_RSVP_BASE_URL'),
    'qr_code_size'  => env('QR_CODE_SIZE', 300),

    'packages' => [
        'basic' => [
            'name'         => 'Basic',
            'sms_units'    => 500,
            'whatsapp'     => false,
            'qr_checkin'   => false,
            'analytics'    => false,
            'price'        => 50000,
        ],
        'premium' => [
            'name'         => 'Premium',
            'sms_units'    => 1000,
            'whatsapp'     => true,
            'qr_checkin'   => false,
            'analytics'    => false,
            'price'        => 120000,
        ],
        'vip' => [
            'name'         => 'VIP',
            'sms_units'    => -1,  // unlimited
            'whatsapp'     => true,
            'qr_checkin'   => true,
            'analytics'    => true,
            'price'        => 350000,
        ],
    ],

    'reminder_schedule' => [7, 3, 1], // days before event
];
