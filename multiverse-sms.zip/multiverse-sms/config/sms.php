<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default SMS Driver
    |--------------------------------------------------------------------------
    | Supported: "smpp", "jasmin", "log"
    */
    'default' => env('SMS_DRIVER', 'jasmin'),

    'drivers' => [

        'smpp' => [
            'host'        => env('SMPP_HOST', '127.0.0.1'),
            'port'        => env('SMPP_PORT', 2775),
            'system_id'   => env('SMPP_SYSTEM_ID'),
            'password'    => env('SMPP_PASSWORD'),
            'system_type' => env('SMPP_SYSTEM_TYPE', ''),
            'tps'         => env('SMPP_TPS', 10),
            'timeout'     => 10,
        ],

        'jasmin' => [
            'host'     => env('JASMIN_HOST', '127.0.0.1'),
            'port'     => env('JASMIN_PORT', 8080),
            'username' => env('JASMIN_USERNAME', 'admin'),
            'password' => env('JASMIN_PASSWORD', 'admin'),
        ],

        'log' => [
            'channel' => 'sms',
        ],
    ],

    'default_sender'    => env('SMPP_DEFAULT_SENDER', 'MULTIVERSE'),
    'price_per_unit'    => env('SMS_PRICE_PER_UNIT', 0.05),
    'currency'          => env('CURRENCY', 'TZS'),
    'dlr_webhook_url'   => env('APP_URL') . '/api/dlr/sms',
    'low_balance_threshold' => env('LOW_BALANCE_THRESHOLD', 1000),

    'statuses' => [
        'ENROUTE'   => 'sent',
        'DELIVERED' => 'delivered',
        'UNDELIV'   => 'failed',
        'EXPIRED'   => 'expired',
        'DELETED'   => 'failed',
        'UNKNOWN'   => 'unknown',
    ],
];
