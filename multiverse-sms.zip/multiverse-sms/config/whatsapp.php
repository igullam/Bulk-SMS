<?php

return [
    'api_version'       => env('WHATSAPP_API_VERSION', 'v18.0'),
    'base_url'          => 'https://graph.facebook.com',
    'phone_number_id'   => env('WHATSAPP_PHONE_NUMBER_ID'),
    'access_token'      => env('WHATSAPP_ACCESS_TOKEN'),
    'verify_token'      => env('WHATSAPP_WEBHOOK_VERIFY_TOKEN'),
    'waba_id'           => env('WHATSAPP_BUSINESS_ACCOUNT_ID'),
    'price_per_unit'    => env('WHATSAPP_PRICE_PER_UNIT', 0.10),
];
