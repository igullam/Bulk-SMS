<?php

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Api\CampaignController;
use App\Http\Controllers\Api\DlrController;
use App\Http\Controllers\Api\WeddingController;
use App\Http\Controllers\Billing\WalletController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Multiverse SMS — API Routes
|--------------------------------------------------------------------------
*/

// ── Public ─────────────────────────────────────────────────────────────────
Route::prefix('auth')->group(function () {
    Route::post('register', [AuthController::class, 'register']);
    Route::post('login',    [AuthController::class, 'login']);
});

// ── DLR Webhooks (no auth — called by Jasmin/SMSC) ────────────────────────
Route::prefix('dlr')->group(function () {
    Route::any('sms',       [DlrController::class, 'sms']);
});

// ── Public Wedding RSVP ────────────────────────────────────────────────────
Route::prefix('rsvp')->group(function () {
    Route::get('{token}',   [WeddingController::class, 'rsvpForm']);
    Route::post('{token}',  [WeddingController::class, 'submitRsvp']);
});

// ── QR Check-in (used by scanner app — no user auth, uses token) ──────────
Route::post('checkin/{token}', [WeddingController::class, 'checkIn']);

// ── Authenticated ──────────────────────────────────────────────────────────
Route::middleware('auth:sanctum')->group(function () {

    Route::get('me', [AuthController::class, 'me']);
    Route::post('logout', [AuthController::class, 'logout']);

    // Campaigns
    Route::prefix('campaigns')->group(function () {
        Route::get('/',              [CampaignController::class, 'index']);
        Route::post('/',             [CampaignController::class, 'store']);
        Route::get('/{campaign}',    [CampaignController::class, 'show']);
        Route::post('/{campaign}/launch', [CampaignController::class, 'launch']);
        Route::post('/{campaign}/pause',  [CampaignController::class, 'pause']);
        Route::get('/{campaign}/stats',   [CampaignController::class, 'stats']);
        Route::delete('/{campaign}', [CampaignController::class, 'destroy']);
    });

    // Wallet & Billing
    Route::prefix('wallet')->group(function () {
        Route::get('/',              [WalletController::class, 'balance']);
        Route::post('topup',         [WalletController::class, 'topUp']);
        Route::get('transactions',   [WalletController::class, 'transactions']);
    });

    // Wedding / Events
    Route::prefix('wedding')->group(function () {
        Route::get('/',                               [WeddingController::class, 'index']);
        Route::post('/',                              [WeddingController::class, 'store']);
        Route::get('/{event}',                        [WeddingController::class, 'show']);
        Route::get('/{event}/dashboard',              [WeddingController::class, 'dashboard']);
        Route::post('/{event}/import-guests',         [WeddingController::class, 'importGuests']);
        Route::post('/{event}/send-invitations',      [WeddingController::class, 'sendInvitations']);
        Route::post('/{event}/send-reminders',        [WeddingController::class, 'sendReminders']);
    });
});
