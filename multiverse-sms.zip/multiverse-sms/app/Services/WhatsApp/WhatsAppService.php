<?php

namespace App\Services\WhatsApp;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class WhatsAppService
{
    protected string $baseUrl;
    protected string $phoneNumberId;
    protected string $accessToken;

    public function __construct()
    {
        $cfg                 = config('whatsapp');
        $this->baseUrl       = "{$cfg['base_url']}/{$cfg['api_version']}";
        $this->phoneNumberId = $cfg['phone_number_id'];
        $this->accessToken   = $cfg['access_token'];
    }

    /**
     * Send a text message.
     */
    public function sendText(string $to, string $message): array
    {
        return $this->call('messages', [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $to,
            'type'              => 'text',
            'text'              => ['body' => $message],
        ]);
    }

    /**
     * Send an approved template (e.g. wedding invitation).
     */
    public function sendTemplate(string $to, string $templateName, string $languageCode = 'en_US', array $components = []): array
    {
        return $this->call('messages', [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
                'name'       => $templateName,
                'language'   => ['code' => $languageCode],
                'components' => $components,
            ],
        ]);
    }

    /**
     * Send an image (e.g. wedding card image).
     */
    public function sendImage(string $to, string $imageUrl, string $caption = ''): array
    {
        return $this->call('messages', [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'image',
            'image'             => ['link' => $imageUrl, 'caption' => $caption],
        ]);
    }

    /**
     * Send a PDF document (e.g. wedding itinerary).
     */
    public function sendDocument(string $to, string $documentUrl, string $filename = 'invitation.pdf', string $caption = ''): array
    {
        return $this->call('messages', [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'document',
            'document'          => [
                'link'     => $documentUrl,
                'filename' => $filename,
                'caption'  => $caption,
            ],
        ]);
    }

    /**
     * Verify webhook challenge from Meta.
     */
    public function verifyWebhook(string $mode, string $token, string $challenge): string|false
    {
        if ($mode === 'subscribe' && $token === config('whatsapp.verify_token')) {
            return $challenge;
        }
        return false;
    }

    protected function call(string $endpoint, array $payload): array
    {
        try {
            $response = Http::withToken($this->accessToken)
                ->post("{$this->baseUrl}/{$this->phoneNumberId}/{$endpoint}", $payload);

            if ($response->successful()) {
                return ['success' => true, 'data' => $response->json()];
            }

            Log::error('WhatsApp API Error', ['response' => $response->json(), 'payload' => $payload]);
            return ['success' => false, 'error' => $response->json()['error']['message'] ?? 'Unknown error'];
        } catch (Exception $e) {
            Log::error('WhatsApp Service Exception: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
