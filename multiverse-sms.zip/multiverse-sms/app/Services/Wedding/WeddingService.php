<?php

namespace App\Services\Wedding;

use App\Models\Event;
use App\Models\Guest;
use App\Models\Rsvp;
use App\Jobs\SendSmsJob;
use App\Jobs\SendWhatsAppJob;
use App\Services\Sms\SmsService;
use App\Services\WhatsApp\WhatsAppService;
use Illuminate\Support\Str;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;

class WeddingService
{
    public function __construct(
        protected SmsService $smsService,
        protected WhatsAppService $whatsAppService
    ) {}

    /**
     * Import guests from an array (parsed from Excel).
     */
    public function importGuests(Event $event, array $rows): int
    {
        $imported = 0;

        foreach ($rows as $row) {
            if (empty($row['phone'])) continue;

            $guest = Guest::updateOrCreate(
                ['event_id' => $event->id, 'phone' => $row['phone']],
                [
                    'name'        => $row['name']        ?? 'Guest',
                    'email'       => $row['email']       ?? null,
                    'family_name' => $row['family']      ?? null,
                    'seat_number' => $row['seat']        ?? null,
                    'table_number'=> $row['table']       ?? null,
                ]
            );

            // Create RSVP record with unique token
            Rsvp::firstOrCreate(
                ['event_id' => $event->id, 'guest_id' => $guest->id],
                ['token' => Str::random(32), 'response' => 'pending']
            );

            $imported++;
        }

        $event->update(['total_guests' => $event->guests()->count()]);
        return $imported;
    }

    /**
     * Send invitations (SMS + optional WhatsApp) to all guests.
     */
    public function sendInvitations(Event $event, bool $sendWhatsApp = false): array
    {
        $sentSms       = 0;
        $sentWhatsApp  = 0;

        $event->guests()->with('rsvp')->chunk(100, function ($guests) use ($event, $sendWhatsApp, &$sentSms, &$sentWhatsApp) {
            foreach ($guests as $guest) {
                $rsvpUrl = config('wedding.rsvp_base_url') . '/' . $guest->rsvp?->token;
                $message = $this->buildInvitationMessage($event, $guest, $rsvpUrl);

                // SMS Invitation
                SendSmsJob::dispatch([
                    'to'      => $guest->phone,
                    'message' => $message,
                    'sender'  => config('sms.default_sender'),
                ])->onQueue('sms');

                $sentSms++;

                // WhatsApp Invitation
                if ($sendWhatsApp && $event->weddingPackage?->whatsapp_enabled) {
                    SendWhatsAppJob::dispatch($guest->phone, 'wedding_invitation', [
                        [
                            'type'       => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $guest->name],
                                ['type' => 'text', 'text' => $event->bride_name . ' & ' . $event->groom_name],
                                ['type' => 'text', 'text' => $event->event_date->format('d M Y')],
                                ['type' => 'text', 'text' => $event->venue],
                                ['type' => 'text', 'text' => $rsvpUrl],
                            ],
                        ],
                    ])->onQueue('whatsapp');

                    $sentWhatsApp++;
                }

                $guest->update(['invitation_sent_at' => now()]);
            }
        });

        return ['sms' => $sentSms, 'whatsapp' => $sentWhatsApp];
    }

    /**
     * Generate a QR code for guest check-in.
     */
    public function generateQrCode(Rsvp $rsvp): string
    {
        $qrContent = route('checkin.scan', ['token' => $rsvp->token]);
        $filename  = "qr/rsvp_{$rsvp->id}.svg";

        $qr = QrCode::size(config('wedding.qr_code_size'))->generate($qrContent);
        Storage::disk('public')->put($filename, $qr);

        $rsvp->update(['qr_code' => $filename]);
        return Storage::url($filename);
    }

    /**
     * Record a check-in via QR scan.
     */
    public function checkIn(string $token): array
    {
        $rsvp = Rsvp::where('token', $token)->with(['event', 'guest'])->firstOrFail();

        if ($rsvp->isCheckedIn()) {
            return ['success' => false, 'message' => 'Already checked in at ' . $rsvp->checked_in_at->format('H:i'), 'rsvp' => $rsvp];
        }

        $rsvp->checkIn();

        return ['success' => true, 'message' => "Welcome, {$rsvp->guest->name}!", 'rsvp' => $rsvp];
    }

    /**
     * Send automated reminders before the event.
     */
    public function sendReminders(Event $event): int
    {
        $pendingGuests = $event->guests()
            ->whereHas('rsvp', fn($q) => $q->where('response', 'pending'))
            ->get();

        $count = 0;

        foreach ($pendingGuests as $guest) {
            $rsvpUrl = config('wedding.rsvp_base_url') . '/' . $guest->rsvp->token;
            $message = "Reminder: You're invited to {$event->name} on {$event->event_date->format('d M Y')} at {$event->venue}. RSVP: {$rsvpUrl}";

            SendSmsJob::dispatch([
                'to'      => $guest->phone,
                'message' => $message,
                'sender'  => config('sms.default_sender'),
            ])->onQueue('sms');

            $count++;
        }

        return $count;
    }

    protected function buildInvitationMessage(Event $event, Guest $guest, string $rsvpUrl): string
    {
        return "Dear {$guest->name}, you are cordially invited to the wedding of {$event->bride_name} & {$event->groom_name} on {$event->event_date->format('d M Y')} at {$event->venue}. RSVP: {$rsvpUrl}";
    }
}
