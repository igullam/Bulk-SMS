<?php

namespace App\Services\Sms;

use App\Models\Campaign;
use App\Models\Message;
use App\Models\User;
use App\Jobs\SendSmsJob;
use Multiverse\Messaging\Facades\Sms;
use Illuminate\Support\Facades\DB;
use Exception;

class SmsService
{
    public function __construct(
        protected WalletService $walletService
    ) {}

    /**
     * Dispatch a campaign to the queue.
     */
    public function dispatchCampaign(Campaign $campaign): void
    {
        $campaign->update(['status' => 'running']);

        $campaign->messages()
            ->where('status', 'pending')
            ->chunk(500, function ($messages) use ($campaign) {
                foreach ($messages as $message) {
                    SendSmsJob::dispatch($message)->onQueue('sms');
                }
            });
    }

    /**
     * Send a single message immediately (bypasses queue).
     */
    public function sendNow(Message $message): array
    {
        $result = Sms::send([
            'to'      => $message->to,
            'message' => $message->message,
            'sender'  => $message->sender,
        ]);

        if ($result['success']) {
            $message->markAsSent($result['message_id']);
            $this->walletService->chargeForMessage($message->user_id, 'sms');
        } else {
            $message->markAsFailed(null, $result['error'] ?? 'Unknown error');
        }

        return $result;
    }

    /**
     * Handle incoming DLR (Delivery Report) webhook.
     */
    public function handleDlr(array $payload): void
    {
        $gatewayMessageId = $payload['id']    ?? $payload['msgid'] ?? null;
        $dlrStatus        = $payload['dlvrd'] ?? $payload['sub']   ?? null;
        $statusCode       = $payload['stat']  ?? null;

        if (!$gatewayMessageId) return;

        $message = Message::where('gateway_message_id', $gatewayMessageId)->first();
        if (!$message) return;

        $mappedStatus = config("sms.statuses.{$statusCode}", 'unknown');

        match ($mappedStatus) {
            'delivered' => $message->markAsDelivered(),
            'failed',
            'expired'   => $message->markAsFailed($statusCode),
            default     => null,
        };

        // Update campaign counters
        if ($message->campaign_id) {
            $this->updateCampaignCounters($message->campaign);
        }
    }

    /**
     * Create messages for a campaign from a contact list.
     */
    public function createCampaignMessages(Campaign $campaign, array $contacts): int
    {
        $messages = array_map(fn($contact) => [
            'campaign_id' => $campaign->id,
            'user_id'     => $campaign->user_id,
            'type'        => 'sms',
            'to'          => $contact['phone'],
            'message'     => $campaign->message,
            'sender'      => $campaign->sender_id ?? config('sms.default_sender'),
            'status'      => 'pending',
            'created_at'  => now(),
            'updated_at'  => now(),
        ], $contacts);

        Message::insert($messages);
        $campaign->update(['total_recipients' => count($messages)]);

        return count($messages);
    }

    protected function updateCampaignCounters(Campaign $campaign): void
    {
        $campaign->update([
            'delivered_count' => $campaign->messages()->where('status', 'delivered')->count(),
            'failed_count'    => $campaign->messages()->whereIn('status', ['failed', 'expired'])->count(),
            'sent_count'      => $campaign->messages()->whereIn('status', ['sent', 'delivered', 'failed'])->count(),
        ]);
    }

    /**
     * Calculate SMS cost (handles multi-part messages).
     */
    public function calculateCost(string $message, int $recipientCount = 1): float
    {
        $parts = $this->countParts($message);
        return $parts * $recipientCount * config('sms.price_per_unit');
    }

    public function countParts(string $message): int
    {
        $length = strlen($message);
        if ($length <= 160) return 1;
        return (int) ceil($length / 153);
    }
}
