<?php

namespace App\Services\Sms;

use App\Models\User;
use App\Models\Wallet;
use Illuminate\Support\Facades\DB;
use Exception;

class WalletService
{
    public function chargeForMessage(int $userId, string $type = 'sms'): void
    {
        $user   = User::findOrFail($userId);
        $price  = $type === 'whatsapp'
            ? config('whatsapp.price_per_unit')
            : config('sms.price_per_unit');

        if (!$user->wallet) return;

        try {
            $user->wallet->debit(
                $price,
                "Charge for {$type} message",
                ['type' => $type]
            );
        } catch (Exception $e) {
            // Log but don't block delivery — handle low-balance notifications separately
        }
    }

    public function topUp(int $userId, float $amount, string $paymentMethod, string $reference): void
    {
        $user = User::findOrFail($userId);

        DB::transaction(function () use ($user, $amount, $paymentMethod, $reference) {
            if (!$user->wallet) {
                $user->wallet()->create(['balance' => 0, 'currency' => config('sms.currency')]);
                $user->refresh();
            }

            $user->wallet->credit($amount, 'Wallet top-up', [
                'payment_method' => $paymentMethod,
                'reference'      => $reference,
            ]);
        });
    }

    public function getBalance(int $userId): float
    {
        return User::findOrFail($userId)->balance;
    }

    public function ensureWalletExists(User $user): Wallet
    {
        return $user->wallet ?? $user->wallet()->create([
            'balance'  => 0,
            'currency' => config('sms.currency'),
        ]);
    }
}
