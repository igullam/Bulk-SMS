<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Campaign extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'name',
        'type',          // sms | whatsapp | both
        'message',
        'sender_id',
        'status',        // draft | scheduled | running | completed | failed | paused
        'scheduled_at',
        'completed_at',
        'total_recipients',
        'sent_count',
        'delivered_count',
        'failed_count',
        'cost',
        'meta',
    ];

    protected $casts = [
        'scheduled_at'  => 'datetime',
        'completed_at'  => 'datetime',
        'meta'          => 'array',
        'cost'          => 'decimal:2',
    ];

    // ─── Scopes ────────────────────────────────────────────────────

    public function scopeDraft($q)       { return $q->where('status', 'draft'); }
    public function scopeScheduled($q)   { return $q->where('status', 'scheduled'); }
    public function scopeRunning($q)     { return $q->where('status', 'running'); }
    public function scopeCompleted($q)   { return $q->where('status', 'completed'); }

    // ─── Relationships ─────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function messages(): HasMany
    {
        return $this->hasMany(Message::class);
    }

    public function sender(): BelongsTo
    {
        return $this->belongsTo(SenderId::class, 'sender_id', 'sender');
    }

    // ─── Helpers ───────────────────────────────────────────────────

    public function getDeliveryRateAttribute(): float
    {
        if ($this->sent_count === 0) return 0;
        return round(($this->delivered_count / $this->sent_count) * 100, 2);
    }

    public function isRunnable(): bool
    {
        return in_array($this->status, ['draft', 'scheduled']);
    }
}
