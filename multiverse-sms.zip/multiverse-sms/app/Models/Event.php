<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Event extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'wedding_package_id',
        'name',
        'type',             // wedding | birthday | corporate | other
        'description',
        'venue',
        'event_date',
        'event_time',
        'bride_name',
        'groom_name',
        'cover_image',
        'settings',         // JSON: colors, fonts, custom message
        'status',           // draft | active | completed | cancelled
        'total_guests',
        'confirmed_rsvps',
        'declined_rsvps',
        'pending_rsvps',
    ];

    protected $casts = [
        'event_date'     => 'date',
        'event_time'     => 'datetime',
        'settings'       => 'array',
    ];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function weddingPackage(): BelongsTo { return $this->belongsTo(WeddingPackage::class); }
    public function rsvps(): HasMany { return $this->hasMany(Rsvp::class); }
    public function guests(): HasMany { return $this->hasMany(Guest::class); }

    public function getDaysUntilEventAttribute(): int
    {
        return now()->diffInDays($this->event_date, false);
    }
}

// ─── RSVP Model ───────────────────────────────────────────────────────────────

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Rsvp extends Model
{
    use HasFactory;

    protected $fillable = [
        'event_id',
        'guest_id',
        'token',
        'response',         // pending | confirmed | declined | maybe
        'attending_count',
        'dietary_notes',
        'message',
        'responded_at',
        'checked_in_at',
        'qr_code',
    ];

    protected $casts = [
        'responded_at'  => 'datetime',
        'checked_in_at' => 'datetime',
    ];

    public function event(): BelongsTo { return $this->belongsTo(Event::class); }
    public function guest(): BelongsTo { return $this->belongsTo(Guest::class); }

    public function isCheckedIn(): bool { return !is_null($this->checked_in_at); }
    public function checkIn(): void { $this->update(['checked_in_at' => now()]); }
}
