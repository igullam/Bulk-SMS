<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Contact extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id', 'group_id', 'name', 'phone', 'email',
        'tags', 'meta', 'is_active', 'opted_out_at',
    ];

    protected $casts = [
        'tags'        => 'array',
        'meta'        => 'array',
        'is_active'   => 'boolean',
        'opted_out_at' => 'datetime',
    ];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function group(): BelongsTo { return $this->belongsTo(ContactGroup::class, 'group_id'); }

    public function hasOptedOut(): bool { return !is_null($this->opted_out_at); }
}
