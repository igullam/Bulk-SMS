<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Message extends Model
{
    use HasFactory;

    protected $fillable = [
        'campaign_id',
        'contact_id',
        'user_id',
        'type',           // sms | whatsapp
        'to',
        'message',
        'sender',
        'gateway_message_id',
        'status',         // pending | sent | delivered | failed | expired
        'cost',
        'sent_at',
        'delivered_at',
        'failed_at',
        'error_code',
        'error_message',
        'meta',
    ];

    protected $casts = [
        'sent_at'      => 'datetime',
        'delivered_at' => 'datetime',
        'failed_at'    => 'datetime',
        'cost'         => 'decimal:4',
        'meta'         => 'array',
    ];

    // ─── Relationships ─────────────────────────────────────────────

    public function campaign(): BelongsTo
    {
        return $this->belongsTo(Campaign::class);
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class);
    }

    public function logs(): HasMany
    {
        return $this->hasMany(MessageLog::class);
    }

    // ─── Helpers ───────────────────────────────────────────────────

    public function markAsSent(string $gatewayMessageId): void
    {
        $this->update([
            'status'             => 'sent',
            'gateway_message_id' => $gatewayMessageId,
            'sent_at'            => now(),
        ]);
    }

    public function markAsDelivered(): void
    {
        $this->update(['status' => 'delivered', 'delivered_at' => now()]);
    }

    public function markAsFailed(string $errorCode = null, string $errorMessage = null): void
    {
        $this->update([
            'status'        => 'failed',
            'failed_at'     => now(),
            'error_code'    => $errorCode,
            'error_message' => $errorMessage,
        ]);
    }
}
