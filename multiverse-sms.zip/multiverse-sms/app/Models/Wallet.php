<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Exception;

class Wallet extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'balance', 'currency', 'is_active'];

    protected $casts = [
        'balance'   => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    public function transactions(): HasMany { return $this->hasMany(Transaction::class); }

    /**
     * Credit the wallet (top-up).
     */
    public function credit(float $amount, string $description = '', array $meta = []): Transaction
    {
        $this->increment('balance', $amount);

        return $this->transactions()->create([
            'type'        => 'credit',
            'amount'      => $amount,
            'balance'     => $this->fresh()->balance,
            'description' => $description,
            'meta'        => $meta,
        ]);
    }

    /**
     * Debit the wallet (usage charge).
     *
     * @throws Exception
     */
    public function debit(float $amount, string $description = '', array $meta = []): Transaction
    {
        if ($this->balance < $amount) {
            throw new Exception('Insufficient wallet balance.');
        }

        $this->decrement('balance', $amount);

        return $this->transactions()->create([
            'type'        => 'debit',
            'amount'      => $amount,
            'balance'     => $this->fresh()->balance,
            'description' => $description,
            'meta'        => $meta,
        ]);
    }

    public function isLow(): bool
    {
        return $this->balance <= config('sms.low_balance_threshold');
    }
}
