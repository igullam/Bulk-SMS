<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Transaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'wallet_id', 'user_id', 'type', // credit | debit
        'amount', 'balance', 'currency',
        'reference', 'description', 'status',
        'payment_method', 'meta',
    ];

    protected $casts = [
        'amount'  => 'decimal:2',
        'balance' => 'decimal:2',
        'meta'    => 'array',
    ];

    public function wallet(): BelongsTo { return $this->belongsTo(Wallet::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    public function isCredit(): bool { return $this->type === 'credit'; }
    public function isDebit(): bool  { return $this->type === 'debit'; }
}


// ─── MessageLog Model ─────────────────────────────────────────────────────────

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MessageLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'message_id', 'event', 'status',
        'gateway_response', 'error', 'logged_at',
    ];

    protected $casts = [
        'gateway_response' => 'array',
        'logged_at'        => 'datetime',
    ];

    public function message(): BelongsTo { return $this->belongsTo(Message::class); }
}
