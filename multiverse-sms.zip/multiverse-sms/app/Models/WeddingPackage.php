<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class WeddingPackage extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'slug', 'description',
        'sms_units', 'whatsapp_enabled',
        'qr_checkin', 'analytics',
        'price', 'currency', 'is_active',
        'features',
    ];

    protected $casts = [
        'whatsapp_enabled' => 'boolean',
        'qr_checkin'       => 'boolean',
        'analytics'        => 'boolean',
        'is_active'        => 'boolean',
        'price'            => 'decimal:2',
        'features'         => 'array',
        'sms_units'        => 'integer', // -1 = unlimited
    ];

    public function events(): HasMany { return $this->hasMany(Event::class); }

    public function isUnlimited(): bool { return $this->sms_units === -1; }
}


// ─── Guest Model ──────────────────────────────────────────────────────────────

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Guest extends Model
{
    use HasFactory;

    protected $fillable = [
        'event_id', 'name', 'phone', 'email',
        'family_name', 'seat_number', 'table_number',
        'invitation_sent_at', 'meta',
    ];

    protected $casts = [
        'invitation_sent_at' => 'datetime',
        'meta'               => 'array',
    ];

    public function event(): BelongsTo { return $this->belongsTo(Event::class); }
    public function rsvp(): HasOne { return $this->hasOne(Rsvp::class); }

    public function hasReplied(): bool
    {
        return $this->rsvp && $this->rsvp->response !== 'pending';
    }
}
