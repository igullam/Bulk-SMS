<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ContactGroup extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'name', 'description', 'contacts_count'];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function contacts(): HasMany { return $this->hasMany(Contact::class, 'group_id'); }
}

// ─── SenderId Model ───────────────────────────────────────────────────────────

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SenderId extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'sender', 'status', 'rejection_reason'];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    public function isApproved(): bool { return $this->status === 'approved'; }
}
