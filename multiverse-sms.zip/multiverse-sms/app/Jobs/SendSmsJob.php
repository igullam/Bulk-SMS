<?php

namespace App\Jobs;

use App\Models\Message;
use App\Services\Sms\SmsService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 3;
    public int $timeout = 60;
    public int $backoff = 30;

    public function __construct(
        public readonly Message|array $message
    ) {}

    public function handle(SmsService $smsService): void
    {
        if ($this->message instanceof Message) {
            $smsService->sendNow($this->message);
        } else {
            // Direct send (e.g. from wedding invitations)
            $params = $this->message;
            \Multiverse\Messaging\Facades\Sms::send($params);
        }
    }

    public function failed(\Throwable $exception): void
    {
        Log::error('SendSmsJob failed', [
            'message'   => $this->message instanceof Message ? $this->message->id : $this->message,
            'exception' => $exception->getMessage(),
        ]);

        if ($this->message instanceof Message) {
            $this->message->markAsFailed(null, $exception->getMessage());
        }
    }
}
