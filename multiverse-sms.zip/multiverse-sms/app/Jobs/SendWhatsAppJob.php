<?php

namespace App\Jobs;

use App\Services\WhatsApp\WhatsAppService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendWhatsAppJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 3;
    public int $timeout = 30;

    public function __construct(
        public readonly string $to,
        public readonly string $template,
        public readonly array  $components = [],
        public readonly string $language   = 'en_US'
    ) {}

    public function handle(WhatsAppService $whatsAppService): void
    {
        $whatsAppService->sendTemplate($this->to, $this->template, $this->language, $this->components);
    }
}
