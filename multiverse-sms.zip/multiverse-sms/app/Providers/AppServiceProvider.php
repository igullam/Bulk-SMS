<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Multiverse\Messaging\SmsManager;
use Multiverse\Messaging\Facades\Sms;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Register Multiverse SMS Package
        $this->app->singleton(SmsManager::class, function ($app) {
            return new SmsManager(config('sms'));
        });

        $this->app->alias(SmsManager::class, 'sms');

        // Register Services
        $this->app->singleton(\App\Services\Sms\SmsService::class);
        $this->app->singleton(\App\Services\Sms\WalletService::class);
        $this->app->singleton(\App\Services\WhatsApp\WhatsAppService::class);
        $this->app->singleton(\App\Services\Wedding\WeddingService::class);
    }

    public function boot(): void
    {
        //
    }
}
