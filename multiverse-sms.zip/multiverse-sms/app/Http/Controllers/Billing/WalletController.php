<?php

namespace App\Http\Controllers\Billing;

use App\Http\Controllers\Controller;
use App\Services\Sms\WalletService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;

class WalletController extends Controller
{
    public function __construct(
        protected WalletService $walletService
    ) {}

    public function balance(Request $request): JsonResponse
    {
        $wallet = $request->user()->wallet()->with('transactions')->first();

        return response()->json([
            'balance'    => $wallet?->balance ?? 0,
            'currency'   => config('sms.currency'),
            'is_low'     => $wallet?->isLow() ?? false,
            'threshold'  => config('sms.low_balance_threshold'),
        ]);
    }

    public function topUp(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'amount'         => 'required|numeric|min:1000',
            'payment_method' => 'required|in:mpesa,airtel_money,tigopesa,bank_transfer,card',
            'reference'      => 'nullable|string',
        ]);

        $reference = $validated['reference'] ?? Str::upper(Str::random(12));

        $this->walletService->topUp(
            $request->user()->id,
            $validated['amount'],
            $validated['payment_method'],
            $reference
        );

        return response()->json([
            'message'   => 'Wallet topped up successfully.',
            'amount'    => $validated['amount'],
            'balance'   => $this->walletService->getBalance($request->user()->id),
            'reference' => $reference,
        ]);
    }

    public function transactions(Request $request): JsonResponse
    {
        $transactions = $request->user()
            ->wallet
            ?->transactions()
            ->latest()
            ->paginate(20);

        return response()->json($transactions);
    }
}
