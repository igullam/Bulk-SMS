<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Campaign;
use App\Services\Sms\SmsService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class CampaignController extends Controller
{
    public function __construct(
        protected SmsService $smsService
    ) {}

    public function index(Request $request): JsonResponse
    {
        $campaigns = $request->user()
            ->campaigns()
            ->with(['messages' => fn($q) => $q->select('campaign_id', 'status')->limit(1)])
            ->latest()
            ->paginate(15);

        return response()->json($campaigns);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name'         => 'required|string|max:255',
            'type'         => 'required|in:sms,whatsapp,both',
            'message'      => 'required|string|max:1600',
            'sender_id'    => 'nullable|string|max:11',
            'scheduled_at' => 'nullable|date|after:now',
            'contacts'     => 'required|array|min:1',
            'contacts.*'   => 'required|string',
        ]);

        $campaign = $request->user()->campaigns()->create([
            'name'         => $validated['name'],
            'type'         => $validated['type'],
            'message'      => $validated['message'],
            'sender_id'    => $validated['sender_id'] ?? config('sms.default_sender'),
            'status'       => $validated['scheduled_at'] ? 'scheduled' : 'draft',
            'scheduled_at' => $validated['scheduled_at'] ?? null,
        ]);

        // Create messages for each contact
        $contacts = array_map(fn($phone) => ['phone' => $phone], $validated['contacts']);
        $count    = $this->smsService->createCampaignMessages($campaign, $contacts);

        // Check balance
        $cost = $this->smsService->calculateCost($campaign->message, $count);
        if (!$request->user()->hasEnoughBalance($cost)) {
            return response()->json([
                'error'    => 'Insufficient balance.',
                'required' => $cost,
                'balance'  => $request->user()->balance,
            ], 402);
        }

        return response()->json([
            'message'   => 'Campaign created successfully.',
            'campaign'  => $campaign->fresh(),
            'recipients'=> $count,
            'cost'      => $cost,
        ], 201);
    }

    public function show(Campaign $campaign): JsonResponse
    {
        $this->authorize('view', $campaign);
        return response()->json($campaign->load('messages'));
    }

    public function launch(Campaign $campaign): JsonResponse
    {
        $this->authorize('update', $campaign);

        if (!$campaign->isRunnable()) {
            return response()->json(['error' => 'Campaign cannot be launched in its current state.'], 422);
        }

        $this->smsService->dispatchCampaign($campaign);

        return response()->json(['message' => 'Campaign launched successfully.', 'campaign' => $campaign->fresh()]);
    }

    public function pause(Campaign $campaign): JsonResponse
    {
        $this->authorize('update', $campaign);
        $campaign->update(['status' => 'paused']);
        return response()->json(['message' => 'Campaign paused.']);
    }

    public function destroy(Campaign $campaign): JsonResponse
    {
        $this->authorize('delete', $campaign);
        $campaign->delete();
        return response()->json(['message' => 'Campaign deleted.']);
    }

    public function stats(Campaign $campaign): JsonResponse
    {
        $this->authorize('view', $campaign);

        return response()->json([
            'total'      => $campaign->total_recipients,
            'sent'       => $campaign->sent_count,
            'delivered'  => $campaign->delivered_count,
            'failed'     => $campaign->failed_count,
            'pending'    => $campaign->messages()->where('status', 'pending')->count(),
            'rate'       => $campaign->delivery_rate,
            'cost'       => $campaign->cost,
        ]);
    }
}
