<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Sms\SmsService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;

class DlrController extends Controller
{
    public function __construct(
        protected SmsService $smsService
    ) {}

    /**
     * Handle SMS delivery reports from Jasmin / SMSC.
     * POST /api/dlr/sms
     */
    public function sms(Request $request): Response
    {
        $payload = $request->all();

        // Jasmin DLR format: id:MSG_ID sub:001 dlvrd:001 submit date:YYMMDDHHMM
        //                     done date:YYMMDDHHMM stat:DELIVRD err:000
        if ($request->has('id')) {
            $this->smsService->handleDlr($payload);
        }

        return response('', 200);
    }
}
