<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Guest;
use App\Models\Rsvp;
use App\Services\Wedding\WeddingService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class WeddingController extends Controller
{
    public function __construct(
        protected WeddingService $weddingService
    ) {}

    public function index(Request $request): JsonResponse
    {
        return response()->json($request->user()->events()->latest()->paginate(10));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name'                 => 'required|string|max:255',
            'type'                 => 'required|in:wedding,birthday,corporate,other',
            'venue'                => 'required|string',
            'event_date'           => 'required|date|after:today',
            'event_time'           => 'nullable|date_format:H:i',
            'bride_name'           => 'nullable|string',
            'groom_name'           => 'nullable|string',
            'wedding_package_id'   => 'required|exists:wedding_packages,id',
            'description'          => 'nullable|string',
        ]);

        $event = $request->user()->events()->create($validated);

        return response()->json(['message' => 'Event created.', 'event' => $event], 201);
    }

    public function show(Event $event): JsonResponse
    {
        $this->authorize('view', $event);
        return response()->json($event->load(['guests.rsvp', 'weddingPackage']));
    }

    public function importGuests(Request $request, Event $event): JsonResponse
    {
        $this->authorize('update', $event);

        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv',
        ]);

        $rows = Excel::toArray([], $request->file('file'))[0];

        // Remove header row
        $headers = array_shift($rows);
        $headers = array_map('strtolower', $headers);

        $guests = array_map(function ($row) use ($headers) {
            return array_combine($headers, $row);
        }, $rows);

        $count = $this->weddingService->importGuests($event, $guests);

        return response()->json(['message' => "{$count} guests imported successfully."]);
    }

    public function sendInvitations(Request $request, Event $event): JsonResponse
    {
        $this->authorize('update', $event);

        $request->validate([
            'send_whatsapp' => 'boolean',
        ]);

        $result = $this->weddingService->sendInvitations($event, $request->boolean('send_whatsapp'));

        return response()->json([
            'message'   => 'Invitations dispatched.',
            'sms_sent'  => $result['sms'],
            'wa_sent'   => $result['whatsapp'],
        ]);
    }

    public function sendReminders(Event $event): JsonResponse
    {
        $this->authorize('update', $event);
        $count = $this->weddingService->sendReminders($event);
        return response()->json(['message' => "{$count} reminders sent."]);
    }

    public function dashboard(Event $event): JsonResponse
    {
        $this->authorize('view', $event);

        $stats = DB::table('rsvps')
            ->where('event_id', $event->id)
            ->select('response', DB::raw('count(*) as total'))
            ->groupBy('response')
            ->pluck('total', 'response');

        return response()->json([
            'event'       => $event,
            'total_guests'=> $event->total_guests,
            'confirmed'   => $stats['confirmed'] ?? 0,
            'declined'    => $stats['declined']  ?? 0,
            'pending'     => $stats['pending']   ?? 0,
            'checked_in'  => Rsvp::where('event_id', $event->id)->whereNotNull('checked_in_at')->count(),
        ]);
    }

    // ─── Public RSVP endpoints (no auth required) ──────────────────

    public function rsvpForm(string $token): JsonResponse
    {
        $rsvp = Rsvp::where('token', $token)->with(['event', 'guest'])->firstOrFail();
        return response()->json(['rsvp' => $rsvp, 'event' => $rsvp->event]);
    }

    public function submitRsvp(Request $request, string $token): JsonResponse
    {
        $rsvp = Rsvp::where('token', $token)->firstOrFail();

        $validated = $request->validate([
            'response'        => 'required|in:confirmed,declined,maybe',
            'attending_count' => 'nullable|integer|min:1|max:10',
            'dietary_notes'   => 'nullable|string|max:255',
            'message'         => 'nullable|string|max:500',
        ]);

        $rsvp->update([...$validated, 'responded_at' => now()]);

        // Update event counters
        $event = $rsvp->event;
        $event->update([
            'confirmed_rsvps' => Rsvp::where('event_id', $event->id)->where('response', 'confirmed')->count(),
            'declined_rsvps'  => Rsvp::where('event_id', $event->id)->where('response', 'declined')->count(),
            'pending_rsvps'   => Rsvp::where('event_id', $event->id)->where('response', 'pending')->count(),
        ]);

        return response()->json(['message' => 'Thank you for your RSVP!', 'response' => $rsvp->response]);
    }

    public function checkIn(string $token): JsonResponse
    {
        $result = $this->weddingService->checkIn($token);
        return response()->json($result, $result['success'] ? 200 : 422);
    }
}
